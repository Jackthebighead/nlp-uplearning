# Lecture 12: Subword Models

### Linguistics

- Phonology
    - 语音学
    - phoneme: 音素, the unique feature
    - of no actual meaning in linguistics
- Morphology: parts of words

    ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled.png)

    - 形态学，词法，形态论
    - morphemes: semantic unit
    - an easy alternative is to work with n-gram character:
        - Wickelphones
        - Microsoft's DSSM
        - related idea is to use convolutional layer
- words in writing system
    - writing systems vary in how to represent words
        - no word segmentation: Chinese
        - words segmented: words components sentences
    - the writing system is different for each language. The data is hard to obtain and process.
- models below the word level: challenges
    - need to handle large, open vocabulary
        - rich morphology, informal spelling, transliteration (many translation is based on spelling).

            ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%201.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%201.png)

### Purely character-level models

- character-level models: 2 methods
    - word embeddings can be composed from character embeddings
        - generates embeddings for unknown words: OOV problem.
        - the similarity between characters: the spelling.
    - connected language can be processed as characters, that is, all languages can be build on top of character-sequences, no consideration of word-level.
    - remarks: both methods have been proven to work successfully.
        - the key is that a  phoneme/character can be grouped by deep learning models, which is not a semantic unit traditionally (the meaning of h, a and t can represent what a 'hat' means?).
        - Deep learning models can construct character-group meaning to represent the semantic.
- Purely character-level model: the second method.
    - we have seen one in the last lecture: use very deep convolutional network for text classification: Conneau, Schwenk, Lecun, Barrault.EACL 2017
        - powerful because of the stacked convolutional layers
    - purely character-level NMT models
        - not very good at first
        - decoders only works fine
        - promising results
            - Luong and Maning built a baseline character-level Seq2Seq LSTM NMT system, worked well. against word-level basedline.
                - but it was slow
            - fully character-level NMT without explicit segmentation

                ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%202.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%202.png)

                - encoder contains ConvNets with segment embeddings and highway networks
                    - input: letter sequence of character embeddings
                    - text convolution layer, max pooling with stride 5, the output is a segment embedding matrix.
                    - multiple layers of highway network
                    - 理解：CNN的应用条件一般是要求卷积对象有局部相关性，而文本是满足的，之前我们用ConvNet作用于word级别的，可以有效识别关键phrases，而用在character-level就是可以识别word pieces信息，n-gram characters，有效构建character-level的LM&embeddings。
                - decoder is a character-level GRU
                    - the decoder is the key and the encoder didn't improve much
            - stronger character results with depth in LSTM Seq2Seq model
                - deeper stacked of LSTM
                - the improvement is bigger in complex languages like 捷克语, but less improvement in English and French.
                - **Word-level is good when model is small while Character-level is better when model is huge.**

### Subword-models: Byte Pair Encoding and friends

- two trends
    - same architecture as for word-level model: but use smaller units—word pieces.
    - hybrid architectures
        - main model has words, something else for characters
        - e.g. for some unknown words we use characters.
- byte pair encoding
    - aka. BPE, doesn't use any algorithms with Deep Learning.
    - originally a **compression** algorithm
        - idea: add the most frequent byte pair as a new byte
        - quite successful in representing pieces of words. 2016-18
        - details

            ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%203.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%203.png)

            - a word segmentation algorithm: bottom up clustering. 分词算法
            - start with a unigram vocabulary of all (Unicode) characters in data
            - the most frequent n-gram pairs form a new n-gram
                - starts from bi-gram
                - clustering based on frequency of n-gram pairs
            - choose a vocabulary size and work until the vocabulary size meets.
            - split data with deterministic longest piece segmentation of word, based on the vocabulary, to form word pieces set.
            - run the MT system using word pieces (as if we are using words).
- Word piece/Sentence piece model by Google NMT
    - use a variant of BPE
        - word piece model
            - tokenizes inside words
        - sentence piece model
            - use the raw data
            - blank space is retained as a special tag.
            - *Subword Regularization: Improving Neural Network Translation Models
            with Multiple Subword Candidates, 2018, Google*
    - idea: rather than using character n-gram count, we can use a greedy approximation to maximizing language model log likelihood to choose the pieces by add n-gram that maximally reduces perplexity (a measure of LM).
        - that's how NN way does!
    - 2018 best WMT
    - BERT uses a variant of the word piece model
        - common words are in the vocabulary. e.g. 1910s, LeBron James.
        - other words are built from word pieces
            - non-initial word pieces are represented with two ##.
        - a large vocabulary, i mean, large. word pieces is a good way to increase the vocabulary. But BERT is not a word-level model.

### Hybrid character and word level models

- character-level to build word-level [LM]

    ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%204.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%204.png)

    - *learning character level representations for POS tagging 2014*
    - convolution over characters to generate word embeddings
    - the difference between pure character model is that here we use character embedding to replace(or represent) word embedding. (still word embedding)
    - then we can use the model to do higher-level task like, fixed window of word embeddings used for POS tagging.
- character-based LSTM to build word representations. [LM]
    - on unknown words

        ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%205.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%205.png)

        - Bi-LSTM
        - the training process: he input is each character, output the embeddings from LSTMs and the goal is to optimize the perplexity as a language model.
    - the whole architecture

        ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%206.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%206.png)

- character-aware Neural Language Models
    - a more complex/sophisticated approach, *Yoon Kim, Yacine Jernite, David Sontag, Alexander M. Rush. 2015.*
    - a combination of the previous 2
        - CNNs over characters in words are better at capturing features and generate character-level embeddings.
            - 理解：CNN的应用条件一般是要求卷积对象有局部相关性，而文本是满足的，之前我们用ConvNet作用于word级别的，可以有效识别关键phrases，而用在character-level就是可以识别word pieces信息，n-gram characters，有效构建character-level的LM&embeddings。
        - RNNs are better at building a LM with context informations
        - the difference between pure character-level model (also CNN_Encoder_RNN_Decoder based) is that here we use character embedding to replace(or represent) word embedding. (still word embedding)
    - motivation: derive a powerful robust language model across a variety of languages.
    - highlights: encode subword correlation, solve OOV (character-based), less parameters (CNN).
    - details
        - architecture

            ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%207.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%207.png)

        - CNN layer

            ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%208.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%208.png)

            - generate character-embedding (many features) for words
        - highway network

            ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%209.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%209.png)

            - LSTM-liked structure in CNN
        - LSTM Decoder

            ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2010.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2010.png)

            - word level
            - hierarchical softmax
            - truncated bp through time for training
    - results
        - comparing size, it is better than simple LSTM
        - comparing perplexity, it is better than word-level models
        - for vocabulary

            ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2011.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2011.png)

            - using char, it is obvious that it learnt character-like things.
            - using highway structure, it learnt more 'meanings' than the previous just-CNN model.
                - because highway structure approximate RNN's function.
        - for OOV, char-model is way more better.

            ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2012.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2012.png)

        - the paper also questioned the necessity of using word embeddings as inputs for neural language modeling since CNN+highway can extract rich semantic and structure information.
- Hybrid NMT: an application
    - a best of both worlds architecture: 2016
    - lots of translation need only word-level, we just need to enter character level when necessary (OOV, <UNK>).
    - architecture

        ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2013.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2013.png)

        - loss at the word level and character level
        - 2-stage decoding: word-level beam search and char-level beam search
    - results: beating word-level and character-level model in NMTin 2016.

### FastText

- chars for word embeddings
    - using characters to build word-embeddings like W2V
    - a joint model for word embedding and word morphology (2016)
    - details

        ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2014.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2014.png)

        - same objective as w2v but using characters
        - bi-LSTM to compute embedding
        - model attempts to capture morphology
        - model can infer roots of words
- FastText: subword model for word embeddings
    - *Bojanowski, Grave, Joulinand Mikolov. FAIR. 2016*
    - motivation: to generate word2vec library, more useful for oov and morphological words and languages.
    - details
        - the expansion of w2v using n-gram character based skip-gram model
        - represent words with n-gram characters with boundary notation.

            ![Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2015.png](Lecture%2012%20Subword%20Models%200cb40e1ee9744647a46245eb11dc1c5b/Untitled%2015.png)

            - $where=<wh,whe,her,ere,re>,<where>$
        - the objective (score) is the total score of components of words.
            - $S(w,c)=\sum_g\in G(w)Z_g^TV_c$
            - the sum of six results (six representations of center word)
            - rather than sharing representation for all n-grams (char-sequences), FastText uses 'hashing trick' to have fixed number of vectors to represent a word.
                - Fowler-Noll-Vo hashing function
    - measure: word similarity.